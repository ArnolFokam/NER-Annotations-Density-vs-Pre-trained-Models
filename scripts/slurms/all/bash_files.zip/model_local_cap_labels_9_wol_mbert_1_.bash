#!/bin/bash
#SBATCH -p batch
#SBATCH -N 1
#SBATCH -t 72:00:00
#SBATCH --nodelist mscluster29
#SBATCH -x mscluster35,mscluster44,mscluster43 
#SBATCH -J local_cap_labels_9_wol_mbert_1_model
#SBATCH -o /home-mscluster/mfokam/ner/logs/local_cap_labels_9_wol_mbert_1/outputs_slurm/model.%N.%j.out
#SBATCH -e /home-mscluster/mfokam/ner/logs/local_cap_labels_9_wol_mbert_1/errors_slurm/model.%N.%j.err

cd /home-mscluster/mfokam/ner
export PYTHONPATH=$PYTHONPATH:`pwd`

python /home-mscluster/mfokam/ner/scripts/train_eval_ner.py --config-path=../exps --config-name=base data.param=9 data.method=local_cap_labels data.language=wol model.conf=[bert,bert-base-multilingual-cased,mbert] device.seed=1

